$('.grid').masonry({
  // options
  itemSelector: '.grid-item',
  horizontalOrder: true
});
